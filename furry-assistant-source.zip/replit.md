# Furry Assistant 1 - Pet Care Companion App

## Overview

Furry Assistant 1 is a comprehensive pet care mobile-first web application that helps pet owners manage their pets' health, activities, nutrition, behavior, and expenses. The app provides AI-powered features for nutrition guidance and behavior suggestions, along with practical tools for tracking medications, vet visits, and daily care routines.

Key features include:
- Pet profile management with photos
- Health records and medication tracking with reminders
- Activity logging with GPS and goal setting
- AI-powered nutrition meal plans and hydration tracking
- Behavior tracking with AI suggestions
- Expense tracking for pet-related costs
- Emergency contacts and first aid guides
- Training resources library
- Admin dashboard for usage analytics

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack Query (React Query) for server state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and CSS variables for theming
- **Build Tool**: Vite with HMR support

The frontend follows a mobile-first design approach with a bottom navigation pattern for core sections (Home, Pets, Activities, Health, More). The design system uses Inter for body text and Poppins for headings, with a warm color palette centered around orange/amber tones.

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **API Design**: RESTful JSON APIs under `/api/*` prefix
- **Authentication**: Replit Auth with OpenID Connect, session-based with PostgreSQL session store
- **AI Integration**: OpenAI API (via Replit AI Integrations) for chat, image generation, and nutrition/behavior suggestions

The server uses a storage abstraction pattern (`IStorage` interface) for database operations, making it easy to swap implementations. Routes are registered modularly with separate files for auth, pets, health, activities, etc.

### Data Layer
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with type-safe schema definitions
- **Schema Location**: `shared/schema.ts` - shared between client and server
- **Migrations**: Drizzle Kit with `drizzle-kit push` for schema updates
- **Validation**: Zod schemas generated from Drizzle schemas via `drizzle-zod`

Core entities include: users, pets, health_records, medications, activities, activity_goals, nutrition_logs, hydration_logs, behavior_logs, expenses, emergency_contacts, training_resources, meal_plans, and feature_usage (for analytics).

### Build System
- **Development**: Vite dev server with Express backend proxy
- **Production**: esbuild bundles server code, Vite builds client to `dist/public`
- **Scripts**: `npm run dev` for development, `npm run build` for production, `npm run db:push` for schema migrations

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connection via `DATABASE_URL` environment variable
- **connect-pg-simple**: Session storage in PostgreSQL

### AI Services
- **OpenAI API**: Used for chat completions, image generation (gpt-image-1), and AI-powered suggestions
- **Environment Variables**: `AI_INTEGRATIONS_OPENAI_API_KEY`, `AI_INTEGRATIONS_OPENAI_BASE_URL`

### Authentication
- **Replit Auth**: OpenID Connect provider for user authentication
- **Environment Variables**: `ISSUER_URL`, `REPL_ID`, `SESSION_SECRET`

### Payment Processing
- **Stripe**: Subscription payment processing with monthly ($9.99) and yearly ($79.99) tiers
- **stripe-replit-sync**: Automatic webhook management and data sync to PostgreSQL stripe schema
- **Environment Variables**: `STRIPE_SECRET_KEY`
- **Endpoints**: 
  - `POST /api/stripe/checkout` - Create checkout session for subscription
  - `POST /api/stripe/portal` - Create customer portal session
  - `GET /api/stripe/prices` - Fetch available subscription prices
- **Critical Pattern**: Query Stripe data from `stripe.*` tables (products, prices, subscriptions), never insert directly into stripe schema. The stripe-replit-sync library manages data synchronization automatically.
- **Product IDs**: Created via `scripts/seed-stripe-products.ts`

### Local Services / Google Places API
- **Google Places API (New)**: Find nearby veterinarians, pet stores, and boarding facilities
- **Environment Variables**: `GOOGLE_PLACES_API_KEY`
- **Endpoint**: `GET /api/places/nearby?lat=&lng=&type=` - Returns nearby pet services from Google Places
- **Place Types Mapped**: veterinary → veterinary_care, groomer/pet_store → pet_store, boarding → lodging

### Third-Party Libraries
- **Radix UI**: Accessible component primitives (dialogs, dropdowns, tabs, etc.)
- **TanStack Query**: Data fetching and caching
- **date-fns**: Date manipulation utilities
- **Lucide React**: Icon library
- **react-hook-form**: Form state management with Zod validation