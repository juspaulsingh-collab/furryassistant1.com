import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Dashboard from "@/pages/Dashboard";
import Pets from "@/pages/Pets";
import PetForm from "@/pages/PetForm";
import Health from "@/pages/Health";
import HealthRecordForm from "@/pages/HealthRecordForm";
import MedicationForm from "@/pages/MedicationForm";
import Activities from "@/pages/Activities";
import ActivityForm from "@/pages/ActivityForm";
import GpsTracking from "@/pages/GpsTracking";
import More from "@/pages/More";
import Nutrition from "@/pages/Nutrition";
import NutritionLogForm from "@/pages/NutritionLogForm";
import HydrationLogForm from "@/pages/HydrationLogForm";
import Behavior from "@/pages/Behavior";
import BehaviorForm from "@/pages/BehaviorForm";
import Training from "@/pages/Training";
import Expenses from "@/pages/Expenses";
import ExpenseForm from "@/pages/ExpenseForm";
import Emergency from "@/pages/Emergency";
import EmergencyContactForm from "@/pages/EmergencyContactForm";
import LocalServices from "@/pages/LocalServices";
import Admin from "@/pages/Admin";
import Forum from "@/pages/Forum";
import ForumPost from "@/pages/ForumPost";
import Subscription from "@/pages/Subscription";
import type { User } from "@shared/schema";

function AuthenticatedRoutes() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/pets" component={Pets} />
      <Route path="/pets/new" component={PetForm} />
      <Route path="/pets/:id" component={PetForm} />
      <Route path="/health" component={Health} />
      <Route path="/health/records/new" component={HealthRecordForm} />
      <Route path="/health/records/:id" component={HealthRecordForm} />
      <Route path="/health/medications/new" component={MedicationForm} />
      <Route path="/health/medications/:id" component={MedicationForm} />
      <Route path="/activities" component={Activities} />
      <Route path="/activities/new" component={ActivityForm} />
      <Route path="/activities/track" component={GpsTracking} />
      <Route path="/activities/:id" component={ActivityForm} />
      <Route path="/more" component={More} />
      <Route path="/nutrition" component={Nutrition} />
      <Route path="/nutrition/logs/new" component={NutritionLogForm} />
      <Route path="/nutrition/logs/:id" component={NutritionLogForm} />
      <Route path="/nutrition/hydration/new" component={HydrationLogForm} />
      <Route path="/nutrition/hydration/:id" component={HydrationLogForm} />
      <Route path="/behavior" component={Behavior} />
      <Route path="/behavior/new" component={BehaviorForm} />
      <Route path="/behavior/:id" component={BehaviorForm} />
      <Route path="/training" component={Training} />
      <Route path="/expenses" component={Expenses} />
      <Route path="/expenses/new" component={ExpenseForm} />
      <Route path="/expenses/:id" component={ExpenseForm} />
      <Route path="/emergency" component={Emergency} />
      <Route path="/emergency/contacts/new" component={EmergencyContactForm} />
      <Route path="/emergency/contacts/:id" component={EmergencyContactForm} />
      <Route path="/services" component={LocalServices} />
      <Route path="/forum" component={Forum} />
      <Route path="/forum/post/:id" component={ForumPost} />
      <Route path="/subscription" component={Subscription} />
      <Route path="/admin" component={Admin} />
      <Route component={NotFound} />
    </Switch>
  );
}

function Router() {
  const { data: user, isLoading } = useQuery<User | null>({
    queryKey: ["/api/auth/user"],
    retry: false,
    queryFn: async () => {
      const res = await fetch("/api/auth/user", { credentials: "include" });
      if (res.status === 401) {
        return null;
      }
      if (!res.ok) {
        throw new Error(`${res.status}: ${res.statusText}`);
      }
      return res.json();
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Landing />;
  }

  return <AuthenticatedRoutes />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
