import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ThemeToggle } from "@/components/ThemeToggle";
import { PawPrint, Heart, Activity, Calendar, Brain, Shield, Sparkles } from "lucide-react";

const features = [
  {
    icon: PawPrint,
    title: "Pet Profiles",
    description: "Store complete profiles for all your furry friends with photos and details"
  },
  {
    icon: Heart,
    title: "Health Tracking",
    description: "Keep track of vet visits, vaccinations, and health records with photo attachments"
  },
  {
    icon: Activity,
    title: "Activity Logging",
    description: "Monitor daily activities, walks, and exercise with customizable goals"
  },
  {
    icon: Calendar,
    title: "Medication Reminders",
    description: "Never miss a dose with medication tracking and refill reminders"
  },
  {
    icon: Brain,
    title: "AI Nutrition Guidance",
    description: "Get personalized meal plans and nutrition advice powered by AI"
  },
  {
    icon: Shield,
    title: "Emergency Ready",
    description: "Quick access to emergency contacts, vets, and first aid guides"
  }
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <PawPrint className="w-8 h-8 text-primary" />
            <span className="font-heading font-bold text-xl">Furry Assistant 1</span>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button asChild data-testid="button-login">
              <a href="/api/login">Sign In with Replit</a>
            </Button>
          </div>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto">
              <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full mb-6">
                <Sparkles className="w-4 h-4" />
                <span className="text-sm font-medium">AI-Powered Pet Care</span>
              </div>
              <h1 className="font-heading font-bold text-4xl md:text-5xl lg:text-6xl mb-6">
                Your Complete Pet Care Companion
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground mb-8">
                Track health records, manage medications, log activities, and get AI-powered nutrition guidance. 
                Everything you need to keep your furry friends happy and healthy.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-lg px-8" asChild data-testid="button-get-started">
                  <a href="/api/login">Get Started Free</a>
                </Button>
                <Button size="lg" variant="outline" className="text-lg px-8" data-testid="button-learn-more">
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-muted/50">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="font-heading font-semibold text-2xl md:text-3xl text-center mb-12">
              Everything Your Pet Needs
            </h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature, index) => (
                <Card key={index} className="hover-elevate" data-testid={`feature-card-${index}`}>
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <feature.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-heading font-semibold text-lg mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="max-w-3xl mx-auto px-4 text-center">
            <h2 className="font-heading font-semibold text-2xl md:text-3xl mb-6">
              Ready to give your pets the best care?
            </h2>
            <p className="text-muted-foreground mb-8">
              Join thousands of pet owners who trust Furry Assistant 1 for their pet care needs.
            </p>
            <Button size="lg" className="text-lg px-8" asChild data-testid="button-signup-bottom">
              <a href="/api/login">Start Your Free Account</a>
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t border-border py-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-muted-foreground">
          <div className="flex items-center justify-center gap-2 mb-2">
            <PawPrint className="w-5 h-5 text-primary" />
            <span className="font-heading font-semibold">Furry Assistant 1</span>
          </div>
          <p className="text-sm">Your trusted companion in pet care</p>
        </div>
      </footer>
    </div>
  );
}
