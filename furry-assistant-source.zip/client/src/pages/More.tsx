import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { BottomNavigation } from "@/components/BottomNavigation";
import { ThemeToggle } from "@/components/ThemeToggle";
import { 
  User, Utensils, Brain, BookOpen, DollarSign, 
  Phone, MapPin, Share2, Shield, ChevronRight,
  LogOut, Settings, Crown, MessageSquare
} from "lucide-react";
import { Link } from "wouter";
import type { User as UserType } from "@shared/schema";

const menuSections = [
  {
    title: "Features",
    items: [
      { icon: Utensils, label: "Nutrition", description: "AI meal plans & food tracking", href: "/nutrition" },
      { icon: Brain, label: "Behavior", description: "Track and understand behavior", href: "/behavior" },
      { icon: BookOpen, label: "Training", description: "Training resources & tips", href: "/training" },
      { icon: DollarSign, label: "Expenses", description: "Track pet-related costs", href: "/expenses" },
    ]
  },
  {
    title: "Community",
    items: [
      { icon: MessageSquare, label: "Forum", description: "Connect with pet owners", href: "/forum" },
    ]
  },
  {
    title: "Emergency",
    items: [
      { icon: Phone, label: "Emergency Contacts", description: "Vets & emergency numbers", href: "/emergency" },
      { icon: MapPin, label: "Local Services", description: "Find vets, groomers, stores", href: "/services" },
    ]
  },
  {
    title: "Account",
    items: [
      { icon: Settings, label: "Settings", description: "App preferences", href: "/settings" },
      { icon: Share2, label: "Share App", description: "Invite friends & family", href: "/share" },
    ]
  }
];

function MenuItem({ 
  icon: Icon, 
  label, 
  description, 
  href,
  badge
}: { 
  icon: typeof User; 
  label: string; 
  description: string; 
  href: string;
  badge?: string;
}) {
  return (
    <Link href={href}>
      <button 
        className="w-full flex items-center gap-3 p-3 rounded-lg hover-elevate text-left"
        data-testid={`menu-${label.toLowerCase().replace(/\s/g, '-')}`}
      >
        <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
          <Icon className="w-5 h-5 text-muted-foreground" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium">{label}</span>
            {badge && <Badge variant="secondary" className="text-xs">{badge}</Badge>}
          </div>
          <p className="text-sm text-muted-foreground truncate">{description}</p>
        </div>
        <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" />
      </button>
    </Link>
  );
}

export default function More() {
  const { data: user } = useQuery<UserType>({
    queryKey: ["/api/auth/user"],
  });

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="max-w-lg mx-auto px-4 h-14 flex items-center justify-between gap-4">
          <h1 className="font-heading font-semibold text-lg">More</h1>
          <ThemeToggle />
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6 space-y-6">
        <Card data-testid="user-profile-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <Avatar className="w-14 h-14">
                <AvatarImage src={user?.profileImageUrl || undefined} />
                <AvatarFallback className="bg-primary/10 text-primary text-lg font-semibold">
                  {user?.firstName?.charAt(0) || user?.email?.charAt(0)?.toUpperCase() || "U"}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="font-semibold truncate">
                    {user?.firstName ? `${user.firstName} ${user.lastName || ""}`.trim() : user?.email || "User"}
                  </h2>
                  {user?.isPremium && (
                    <Badge className="bg-amber-500/20 text-amber-600 dark:text-amber-400">
                      <Crown className="w-3 h-3 mr-1" />
                      Premium
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground truncate">{user?.email}</p>
              </div>
            </div>
            {!user?.isPremium && (
              <Link href="/subscription">
                <Button className="w-full mt-4" variant="outline" data-testid="button-upgrade">
                  <Crown className="w-4 h-4 mr-2 text-amber-500" />
                  Upgrade to Premium
                </Button>
              </Link>
            )}
          </CardContent>
        </Card>

        {user?.isAdmin && (
          <Card className="border-primary/20 bg-primary/5" data-testid="admin-card">
            <CardContent className="p-4">
              <Link href="/admin">
                <button className="w-full flex items-center gap-3 text-left">
                  <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                    <Shield className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <span className="font-medium">Admin Portal</span>
                    <p className="text-sm text-muted-foreground">Manage users & analytics</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-primary" />
                </button>
              </Link>
            </CardContent>
          </Card>
        )}

        {menuSections.map((section) => (
          <section key={section.title}>
            <h2 className="text-sm font-medium text-muted-foreground mb-2 px-1">
              {section.title}
            </h2>
            <Card>
              <CardContent className="p-2">
                {section.items.map((item, index) => (
                  <MenuItem key={item.label} {...item} />
                ))}
              </CardContent>
            </Card>
          </section>
        ))}

        <Card>
          <CardContent className="p-2">
            <a href="/api/logout">
              <button 
                className="w-full flex items-center gap-3 p-3 rounded-lg hover-elevate text-left"
                data-testid="button-logout"
              >
                <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center">
                  <LogOut className="w-5 h-5 text-destructive" />
                </div>
                <span className="font-medium text-destructive">Sign Out</span>
              </button>
            </a>
          </CardContent>
        </Card>
      </main>

      <BottomNavigation />
    </div>
  );
}
