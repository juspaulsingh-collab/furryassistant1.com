import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BottomNavigation } from "@/components/BottomNavigation";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useToast } from "@/hooks/use-toast";
import { 
  Crown, Check, ArrowLeft, Sparkles, Brain, Utensils,
  Star, Shield, BarChart3, Users, Loader2, ExternalLink
} from "lucide-react";
import { Link, useSearch, useLocation } from "wouter";
import { format } from "date-fns";
import { useEffect, useRef } from "react";
import type { Subscription, User } from "@shared/schema";

const features = [
  { icon: Utensils, title: "AI Meal Plans", description: "Personalized nutrition plans for your pets" },
  { icon: Brain, title: "AI Behavior Analysis", description: "Smart suggestions for behavior issues" },
  { icon: Users, title: "Unlimited Pets", description: "Add as many pets as you want" },
  { icon: BarChart3, title: "Advanced Analytics", description: "Detailed health and activity insights" },
  { icon: Shield, title: "Priority Support", description: "Get help when you need it most" },
  { icon: Sparkles, title: "Early Access", description: "Be first to try new features" },
];

interface StripePrice {
  product_id: string;
  product_name: string;
  product_description: string;
  price_id: string;
  unit_amount: number;
  currency: string;
  recurring: { interval: string } | null;
  price_metadata: { plan?: string } | null;
}

export default function SubscriptionPage() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const searchString = useSearch();
  const searchParams = new URLSearchParams(searchString);
  const success = searchParams.get("success");
  const cancelled = searchParams.get("cancelled");
  const toastShownRef = useRef(false);

  useEffect(() => {
    if (toastShownRef.current) return;
    
    if (success === "true") {
      toastShownRef.current = true;
      toast({
        title: "Payment successful!",
        description: "Welcome to Furry Assistant 1 Premium. Enjoy all the premium features!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setLocation("/subscription", { replace: true });
    } else if (cancelled === "true") {
      toastShownRef.current = true;
      toast({
        title: "Payment cancelled",
        description: "Your subscription was not created.",
        variant: "destructive",
      });
      setLocation("/subscription", { replace: true });
    }
  }, [success, cancelled, toast, setLocation]);

  const { data: user } = useQuery<User>({
    queryKey: ["/api/auth/user"],
  });

  const { data: subscription, isLoading: subscriptionLoading } = useQuery<Subscription | null>({
    queryKey: ["/api/subscription"],
  });

  const { data: prices, isLoading: pricesLoading } = useQuery<StripePrice[]>({
    queryKey: ["/api/stripe/prices"],
  });

  const checkoutMutation = useMutation({
    mutationFn: async (priceId: string) => {
      const res = await apiRequest("POST", "/api/stripe/checkout", { priceId });
      return res.json();
    },
    onSuccess: (data) => {
      if (data.url) {
        window.location.href = data.url;
      }
    },
    onError: () => {
      toast({
        title: "Checkout failed",
        description: "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const portalMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/stripe/portal");
      return res.json();
    },
    onSuccess: (data) => {
      if (data.url) {
        window.location.href = data.url;
      }
    },
    onError: () => {
      toast({
        title: "Could not open billing portal",
        description: "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const formatPrice = (amount: number) => {
    return `$${(amount / 100).toFixed(2)}`;
  };

  const sortedPrices = prices?.sort((a, b) => a.unit_amount - b.unit_amount) || [];
  const monthlyPrice = sortedPrices.find(p => p.recurring?.interval === "month");
  const yearlyPrice = sortedPrices.find(p => p.recurring?.interval === "year");

  const plans = [
    {
      id: "monthly",
      priceId: monthlyPrice?.price_id,
      name: "Monthly",
      price: monthlyPrice ? formatPrice(monthlyPrice.unit_amount) : "$9.99",
      period: "/month",
      description: "Perfect for trying premium features",
      popular: false,
    },
    {
      id: "yearly",
      priceId: yearlyPrice?.price_id,
      name: "Yearly",
      price: yearlyPrice ? formatPrice(yearlyPrice.unit_amount) : "$79.99",
      period: "/year",
      description: "Save 33% with annual billing",
      popular: true,
    },
  ];

  const isLoading = subscriptionLoading || pricesLoading;

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="max-w-lg mx-auto px-4 h-14 flex items-center justify-between gap-4">
          <Link href="/more">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <h1 className="font-heading font-semibold text-lg">Premium</h1>
          <ThemeToggle />
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6 space-y-6">
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
          </div>
        ) : subscription && user?.isPremium ? (
          <Card data-testid="subscription-status-card">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Crown className="w-6 h-6 text-amber-500" />
                <CardTitle>Premium Active</CardTitle>
              </div>
              <CardDescription>
                You're enjoying all premium features
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                <div>
                  <p className="font-medium capitalize">{subscription.plan} Plan</p>
                  <p className="text-sm text-muted-foreground">
                    {subscription.endDate 
                      ? `Renews ${format(new Date(subscription.endDate), "MMM d, yyyy")}`
                      : "Active subscription"
                    }
                  </p>
                </div>
                <Badge className="bg-green-500/20 text-green-600 dark:text-green-400">
                  Active
                </Badge>
              </div>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => portalMutation.mutate()}
                disabled={portalMutation.isPending}
                data-testid="button-manage-subscription"
              >
                {portalMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <ExternalLink className="w-4 h-4 mr-2" />
                )}
                Manage Subscription
              </Button>
            </CardContent>
          </Card>
        ) : (
          <>
            <div className="text-center space-y-2">
              <div className="flex justify-center">
                <div className="w-16 h-16 rounded-full bg-amber-500/20 flex items-center justify-center">
                  <Crown className="w-8 h-8 text-amber-500" />
                </div>
              </div>
              <h2 className="font-heading font-bold text-2xl">Upgrade to Premium</h2>
              <p className="text-muted-foreground">
                Unlock powerful features to give your pets the best care
              </p>
            </div>

            <div className="space-y-3">
              {plans.map((plan) => (
                <Card 
                  key={plan.id}
                  className={plan.popular ? "border-amber-500 border-2" : ""}
                  data-testid={`plan-card-${plan.id}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-lg">{plan.name}</h3>
                          {plan.popular && (
                            <Badge className="bg-amber-500/20 text-amber-600 dark:text-amber-400">
                              <Star className="w-3 h-3 mr-1" />
                              Best Value
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{plan.description}</p>
                      </div>
                      <div className="text-right">
                        <span className="text-2xl font-bold">{plan.price}</span>
                        <span className="text-muted-foreground">{plan.period}</span>
                      </div>
                    </div>
                    <Button 
                      className="w-full"
                      variant={plan.popular ? "default" : "outline"}
                      onClick={() => plan.priceId && checkoutMutation.mutate(plan.priceId)}
                      disabled={checkoutMutation.isPending || !plan.priceId || pricesLoading}
                      data-testid={`button-subscribe-${plan.id}`}
                    >
                      {checkoutMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Redirecting to checkout...
                        </>
                      ) : pricesLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Loading...
                        </>
                      ) : (
                        `Choose ${plan.name}`
                      )}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}

        <div className="space-y-4">
          <h3 className="font-heading font-semibold text-lg">Premium Features</h3>
          <div className="grid gap-3">
            {features.map((feature, index) => (
              <div 
                key={index}
                className="flex items-start gap-3 p-3 rounded-lg bg-muted/50"
                data-testid={`feature-item-${index}`}
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-medium">{feature.title}</h4>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </div>
                <Check className="w-5 h-5 text-green-500 shrink-0 ml-auto" />
              </div>
            ))}
          </div>
        </div>

        <div className="text-center text-sm text-muted-foreground p-4">
          <p>Secure payments powered by Stripe</p>
          <p className="mt-1">Cancel anytime from the billing portal</p>
        </div>
      </main>

      <BottomNavigation />
    </div>
  );
}
